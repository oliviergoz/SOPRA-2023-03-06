package projetHopital.dao;

import projetHopital.model.Patient;

public interface PatientDao extends DaoGeneric<Patient, Integer> {

}
