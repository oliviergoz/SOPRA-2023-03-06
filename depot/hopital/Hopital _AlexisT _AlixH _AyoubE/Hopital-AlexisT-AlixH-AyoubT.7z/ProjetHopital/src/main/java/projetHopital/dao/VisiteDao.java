package projetHopital.dao;

import projetHopital.model.Visite;

public interface VisiteDao extends DaoGeneric<Visite, Integer>{

}
