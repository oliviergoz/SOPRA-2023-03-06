package projetHopital.dao;

import projetHopital.model.Compte;

public interface CompteDao extends DaoGeneric<Compte, Integer>{

}
