package projetHopital.dao;

public class DaoMedecinImpl implements DaoMedecin {

  @Override
  public void medecindispo() {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException(
      "Unimplemented method 'medecindispo'"
    );
  }

  @Override
  public void sauvegardeVisit() {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException(
      "Unimplemented method 'sauvegardeVisit'"
    );
  }
}
