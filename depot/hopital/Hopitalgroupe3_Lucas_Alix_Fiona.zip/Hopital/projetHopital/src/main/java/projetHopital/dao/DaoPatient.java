package projetHopital.dao;

import projetHopital.model.Patient;

public interface DaoPatient extends DaoGeneric<Patient, Integer>{

}
