package projetHopital.lanceur;

public class Lanceur {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
