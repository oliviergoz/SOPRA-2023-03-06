package env;

public class Environnement {
	

	public static String cheminFile = "."; // dépends de l'OS

}
