package projetHopital.dao;

import projetHopital.model.Visite;

public interface DaoVisite extends DaoGeneric<Visite, Integer>{

}
