package dao;

import java.util.List;

import model.Compte;

public class DAOCompte implements IDAOCompte{

	@Override
	public Compte findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Compte> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Compte o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Compte o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Compte findByLoginAndPassword(String login, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
