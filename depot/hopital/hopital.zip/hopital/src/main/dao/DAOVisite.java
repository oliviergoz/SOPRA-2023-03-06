package dao;

import java.util.List;

import model.Visite;

public class DAOVisite implements IDAOVisite {

	@Override
	public Visite findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Visite> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Visite o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Visite o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Visite> findAllByPatient(Integer idPatient) {
		// TODO Auto-generated method stub
		return null;
	}

}
