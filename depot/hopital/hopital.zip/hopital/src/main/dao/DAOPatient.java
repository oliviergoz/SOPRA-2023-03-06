package dao;

import java.util.List;

import model.Patient;

public class DAOPatient implements IDAOPatient{

	@Override
	public Patient findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Patient> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Patient o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Patient o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		
	}

}
